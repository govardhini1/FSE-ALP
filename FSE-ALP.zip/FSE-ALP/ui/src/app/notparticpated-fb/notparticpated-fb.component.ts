import { Component, OnInit } from '@angular/core';
import { FeedBackData } from '../shared/Models/FeedBack';
import { AppServiceService } from '../app-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notparticpated-fb',
  templateUrl: './notparticpated-fb.component.html',
  styleUrls: ['./notparticpated-fb.component.scss']
})
export class NotparticpatedFbComponent implements OnInit {

  public feedbackDetails : FeedBackData[] = [];
  public eventDetails :any;
  public participantsDetails :any;
  feedbackdet : FeedBackData  = new FeedBackData();
  public toggle : boolean = false;
  public selectedAnswer : string;
  public buttonColor : string = '#000';
  public selectedButton : string = '';
  public enable : boolean = false;
  public Question : String;

  constructor(private appService: AppServiceService, private router: Router) { }

  ngOnInit() {
    this.appService.getFeedbacks().subscribe(data => {
      console.log(data);
    data.forEach(element => {
      if(element.feedbackType == "Not Participated") {
        console.log(element.feedbackType);
          this.Question = element.question;
          this.feedbackDetails.push(element);
          console.log(this.feedbackDetails);
          }
    });
     
    });
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
    });
  }
  answers(event) {
    this.selectedButton = event.target.id; 
    this.selectedAnswer = event.target.value;
    console.log(this.selectedButton);
    console.log(  this.selectedAnswer);
  }

  submit() {
    this.feedbackDetails.forEach(e => {
      if(e.feedbackType ===  'Not Participated') {
          this.feedbackdet.question = e.question;
      }
    });
    this.feedbackdet.feedbackType = 'Not Participated';
    this.feedbackdet.answer = this.selectedAnswer;
    // this.feedbackdet.question = '';
    console.log(this.feedbackdet) 
    this.appService.createFeedbacks(this.feedbackdet).subscribe(data =>  {
      this.feedbackdet = new FeedBackData(); 
      console.log(data),
      error => console.log(error)
    });
    this.router.navigate(['/InfoScreen']);
  }

  Reset(){
    this.selectedButton = ''; 
  }
}
