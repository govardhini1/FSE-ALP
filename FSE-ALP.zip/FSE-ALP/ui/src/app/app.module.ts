import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { EventListComponent } from './event-list/event-list.component';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { ActionComponent } from './shared/action/action.component';
import { ReportsComponent } from './reports/reports.component';
import { RolesComponent } from './roles/roles.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ParticpantFbComponent } from './particpant-fb/particpant-fb.component';
import { NotparticpatedFbComponent } from './notparticpated-fb/notparticpated-fb.component';
import { UnregisteredFbComponent } from './unregistered-fb/unregistered-fb.component';
import { InfoFbComponent } from './info-fb/info-fb.component';
import { AddfeedbackComponent } from './addfeedback/addfeedback.component';
import { EditFeedbackComponent } from './edit-feedback/edit-feedback.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    EventListComponent,
    EventDetailComponent,
    ActionComponent,
    ReportsComponent,
    RolesComponent,
    FeedbackComponent,
    ParticpantFbComponent,
    NotparticpatedFbComponent,
    UnregisteredFbComponent,
    InfoFbComponent,
    AddfeedbackComponent,
    EditFeedbackComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
