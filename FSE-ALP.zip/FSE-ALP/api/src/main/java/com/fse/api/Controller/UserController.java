package com.fse.api.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fse.api.Repository.UserRepository;
import com.fse.api.entity.User;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/")
public class UserController {
	
	@Autowired
	  private UserRepository userRepository;
	  /**
	   * Get all users list.
	   *
	   * @return the list
	   */
	  @GetMapping("/user")
	  public List<User> getAllUsers() {
	    return (List<User>) userRepository.findAll();
	  }
	  
	  @PostMapping("/create")
	  public String createUser(@RequestBody User user) {
	  userRepository.save(user);
	  return "Record Created Successfully!" + user.getId() + " " + user.getEmail() + "" + user.getRole();
	  }
}
