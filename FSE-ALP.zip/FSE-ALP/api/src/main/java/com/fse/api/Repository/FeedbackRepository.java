package com.fse.api.Repository;

import org.springframework.data.repository.CrudRepository;
import com.fse.api.entity.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback,Long>{

}
