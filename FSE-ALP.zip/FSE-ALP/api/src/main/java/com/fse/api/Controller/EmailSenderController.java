package com.fse.api.Controller;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fse.api.model.Email;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(value="/email")
public class EmailSenderController {
	
	@Autowired
	public JavaMailSender  javaMailSender;
	
	@GetMapping(value="/sendEmail")
	public String sendMail() {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo("govardhinimech17@gmail.com");
		message.setSubject("Outreach Event Feedback");
		message.setText("Please provide ur feedback");
		javaMailSender.send(message);
		return "email sent successfully";
		
	}
	
	@PostMapping(value="/sendFeedback")
	public String sendMail(@RequestBody Email email) throws MessagingException {
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		helper.setTo(email.getToAddress());
		helper.setSubject("Outreach Event Feedback");
		helper.setText(email.getMessageBody(), true);
		javaMailSender.send(message);
		return "email sent successfully";
		
	}

}
