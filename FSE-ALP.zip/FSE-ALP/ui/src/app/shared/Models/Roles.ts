export class Role {
    id : Number;
    emailId : String;
    name : String;
    role : String;
    constructor() {
        
    }
}