import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FeedBackData } from './shared/Models/FeedBack';
import { Observable } from 'rxjs';
import { User } from './shared/Models/user';
import { Participants } from './shared/Models/participants';
import { Enrollments } from './shared/Models/Enrollments';
import { Role } from './shared/Models/Roles';


@Injectable({
  providedIn: 'root'
})
export class AppServiceService {

  private apiContext = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  getUsers() : Observable<User[]> {
    return this.http.get<User[]>('http://localhost:8080/user');
  }
  
  // getUsers() : Observable<User[]> {
  //   return this.http.get<User[]>('assets/mockdata/user.json');
  // }

  saveUsers(user : User) : Observable<any> {
    return this.http.post<any>('http://localhost:8080/create',user, {
      headers : new HttpHeaders({
        'Content-Type' : 'application/json'
      })
  })
  }
  getEvents() {
    return this.http.get('http://localhost:8080/EventSummary');
  }

   getEventsById(eventId : String) {
    return this.http.get('http://localhost:8080/EventSummary/' + eventId);
  }
  getParticiants() : Observable<Participants[]>{
    return this.http.get<Participants[]>('http://localhost:8080/Participants');
  }
  getFeedbacks() : Observable<FeedBackData[]>{
    return this.http.get<FeedBackData[]>('http://localhost:8080/Feedback');
  }
  
  // getFeedbacks() : Observable<FeedBackData[]>{
  //   return this.http.get<FeedBackData[]>('assets/mockdata/Feedback.json');
  // }

  getFeedbacksById(FeedbackId : number) : Observable<any> {
    return this.http.get('http://localhost:8080/Feedback/' + FeedbackId);
  }
  createFeedbacks(feedback : Object) : Observable<Object> {
    return this.http.post('http://localhost:8080/addFeedback',feedback, {
        headers : new HttpHeaders({
          'Content-Type' : 'application/json'
        })
    })
  }
  upateFeedback(id: number, value : any) : Observable<Object> {
    return this.http.put('http://localhost:8080/updateFeedback/'+ id,value, {
      headers : new HttpHeaders({
        'Content-Type' : 'application/json'
      })
  })
  }

  DeleteFeedbacks(feedbackId : Number) : Observable<any> {
    //deleteFeedback
    return this.http.delete('http://localhost:8080/deleteFeedback/' + feedbackId, {responseType: 'text'});
  }
  sendMail(Email : Object) : Observable<Object> {
    return this.http.post('http://localhost:8080/email/sendFeedback',Email, {responseType: 'text'});
  }

  getQuestions() : Observable<Enrollments[]>{
    return this.http.get<Enrollments[]>('http://localhost:8080/Enrollments');
  }
  // getQuestions() : Observable<Enrollments[]>{
  //   return this.http.get<Enrollments[]>('assets/mockdata/Enrollments.json');
  // }
  createQuestions(questions : Object) : Observable<Object> {
    return this.http.post('http://localhost:8080/addQuestions',questions, {
        headers : new HttpHeaders({
          'Content-Type' : 'application/json'
        })
    })
  }
  DeleteQuestions(questionId : Number) : Observable<any> {
    //deletequestion
    return this.http.delete('http://localhost:8080/deleteQuestions/' + questionId, {responseType: 'text'});
  }

  getPmoDetails() : Observable<Role[]>{
    return this.http.get<Role[]>('http://localhost:8080/Roles');
  }
  // getQuestions() : Observable<Enrollments[]>{
  //   return this.http.get<Enrollments[]>('assets/mockdata/Enrollments.json');
  // }
  createPmos(roles : Object) : Observable<Object> {
    return this.http.post('http://localhost:8080/addRoles',roles, {
        headers : new HttpHeaders({
          'Content-Type' : 'application/json'
        })
    })
  }
  DeletePmos(id : Number) : Observable<any> {
    //deletequestion
    return this.http.delete('http://localhost:8080/deleteRoles/' + id, {responseType: 'text'});
  }
}
