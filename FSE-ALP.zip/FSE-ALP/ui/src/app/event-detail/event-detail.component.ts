import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppServiceService } from '../app-service.service';

@Component({
  selector: 'app-event-detail',
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.scss']
})
export class EventDetailComponent implements OnInit {

  public eventDetails: any;
  public participantsDetails: any;
  eventID:String
  eventByIDDetails : any
  constructor(private router: Router, private appService: AppServiceService, private route : ActivatedRoute) { }

  ngOnInit() {
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
    });
    this.appService.getParticiants().subscribe(data => {
      this.participantsDetails = data;
      console.log(this.participantsDetails);
    })
    this.eventID = this.route.snapshot.params['id'];
    this.appService.getEventsById(this.eventID).subscribe(data => {
      this.eventByIDDetails = data;
      console.log(this.eventByIDDetails);
    });

  }

}
