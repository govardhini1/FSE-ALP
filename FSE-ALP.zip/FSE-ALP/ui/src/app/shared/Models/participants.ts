export class Participants {
    id: string
    enrollment: string
    status: string
    eventName: string
    eventDate: string
    base_Location: string
    councilName: string
    employee_ID: string
    employee_Name: string
    travel_Hours: number
    business_Unit: string
    iiep_Category: string
    email_Id: string
    beneficiaryName: string
    eventDescription: string
    volunteer_Hours: number
    lives_Impacted: number

}


