import { Component, OnInit, Input } from '@angular/core';
import { AppServiceService } from 'src/app/app-service.service';
import { LoginComponent } from 'src/app/login/login.component';
import { AuthenticationService } from '../Services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private appservice : AppServiceService, private loginservice: AuthenticationService, private router : Router ) { }

  public user : any;
  public role : String;
  public adminRole : boolean =  false;
  public otherRole : boolean =  false;
  public participantRole : boolean =  false;
 // private login: LoginComponent;
 public username : any;

  ngOnInit() {
    // console.log(this.login.Password); 
     
   // this.loginservice.isUserLoggedIn();
   this.appservice.getUsers().subscribe(Response => {
    this.user = Response;
    console.log(this.user);
    this.user.forEach((element : any) => {
       this.username = sessionStorage.getItem('username');
      if(this.username == element.email) {
        this.role = element.role;
        if(this.role == 'Admin'){
          this.adminRole = true;
          console.log(this.role, this.adminRole);
        } else if(this.role == 'Pmo' || this.role == 'Poc') {
          this.otherRole = true;
          this.adminRole = false;
          console.log(this.role, this.otherRole);
        } else {
          this.participantRole = true;
          console.log(this.role, this.participantRole);
        }

           console.log(this.role);
      }
      
    })
  }) 
  }

// ngAfterviewinit(){
//   setTimeout (() => {
//   this.appservice.getUsers().subscribe(Response => {
//     this.user = Response;
//     console.log(this.user);
//     this.user.forEach((element : any) => {
//       let username = sessionStorage.getItem('username');
//       if(username == element.email) {
//         this.role = element.role;
//         if(this.role == 'Admin'){
//           this.adminRole = true;
//         } else if(this.role == 'Pmo' || this.role == 'Poc') {
//           this.otherRole = true;
//         } else {
//           this.participantRole = true;
//         }

//            console.log(this.role);
//       }
      
//     })
//   }) 
//   }, 1000);
// }
  logout() {
    console.log('hello')
    this.loginservice.logOut();
    this.router.navigate(['login']);
 
  }

}
