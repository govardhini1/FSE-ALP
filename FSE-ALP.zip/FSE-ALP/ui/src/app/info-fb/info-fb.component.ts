import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-fb',
  templateUrl: './info-fb.component.html',
  styleUrls: ['./info-fb.component.scss']
})
export class InfoFbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
