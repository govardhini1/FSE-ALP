export class Enrollments {
    id: number;
    questions: String;
    enrollmentType: String;
    constructor() {
        this.id = null;
        this.questions = '';
        this.enrollmentType = ''
    }
    }