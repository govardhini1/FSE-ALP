import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnregisteredFbComponent } from './unregistered-fb.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

describe('UnregisteredFbComponent', () => {
  let component: UnregisteredFbComponent;
  let fixture: ComponentFixture<UnregisteredFbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnregisteredFbComponent ],
      imports : [  FormsModule,
        HttpClientModule],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnregisteredFbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
