import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { EventListComponent } from './event-list/event-list.component';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { ReportsComponent } from './reports/reports.component';
import { RolesComponent } from './roles/roles.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ParticpantFbComponent } from './particpant-fb/particpant-fb.component';
import { NotparticpatedFbComponent } from './notparticpated-fb/notparticpated-fb.component';
import { UnregisteredFbComponent } from './unregistered-fb/unregistered-fb.component';
import { InfoFbComponent } from './info-fb/info-fb.component';
import { EditFeedbackComponent } from './edit-feedback/edit-feedback.component';
import { AddfeedbackComponent } from './addfeedback/addfeedback.component';
import { HeaderComponent } from './shared/header/header.component';
import { AuthGaurdService } from './shared/Services/auth-gaurd.service';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  // {
  //   path: 'header',
  //   component: HeaderComponent
  // },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'eventList',
    component: EventListComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'eventList/:id',
    component: EventDetailComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'Reports',
    component: ReportsComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'Roles',
    component: RolesComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'Feedback',
    component: FeedbackComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'addfeedback',
    component: AddfeedbackComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'editfeedback/:id',
    component: EditFeedbackComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'Participants',
    component: ParticpantFbComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'NonParticipants',
    component: NotparticpatedFbComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'unregister',
    component: UnregisteredFbComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: 'InfoScreen',
    component: InfoFbComponent,
    canActivate:[AuthGaurdService]
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
