import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppServiceService } from '../app-service.service';
import { FeedBackData } from '../shared/Models/FeedBack';

@Component({
  selector: 'app-edit-feedback',
  templateUrl: './edit-feedback.component.html',
  styleUrls: ['./edit-feedback.component.scss']
})
export class EditFeedbackComponent implements OnInit {

  ID: number;
  feedback: FeedBackData;
  question: String = '';
  answer: String = '';
  feedbackType: String = '';
  FeedbackID: number;
  feedbackdata: any;
  public feedbackDetails: any;
  public SelectedValue: String;
  public radioValue1: boolean = false;
  public radioValue2: boolean = false;
  public radioValue3: boolean = false;
  constructor(private router: Router, private appService: AppServiceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.feedback = new FeedBackData();
    this.FeedbackID = this.route.snapshot.params['id'];
    this.appService.getFeedbacksById(this.FeedbackID).subscribe(data => {
      this.feedback = data;
      console.log(data);
      if (this.feedback.feedbackType == "Participated") {
        console.log(this.feedback.feedbackType);
        this.radioValue1 = true;
      } else if (this.feedback.feedbackType == "Not Participated") {
        console.log(this.feedback.feedbackType);
        this.radioValue2 = true;
      } else {
        this.radioValue3 = true;
      }

    }, error => console.log(error));
  }

  Cancel() {
    this.router.navigate(['Feedback']);
  }

  getFeedback() {
    this.appService.getFeedbacks().subscribe(data => {
      this.feedbackDetails = data;
      console.log(this.feedbackDetails);
    });
  }

  // editSave(id : Number) {
  //   this.FeedbackID = this.route.snapshot.params['id'];
  //   this.appService.getFeedbacksById( this.FeedbackID).subscribe(feedback => {
  //     this.feedbackdata = feedback;
  //     console.log(this.feedbackdata);
  //     this.ID = feedback.id;
  //     this.question = feedback.question;
  //     this.answer = feedback.answer;
  //     this.feedbackType = feedback.feedbackType;
  //   })
  // }

  editSave() {
    this.appService.upateFeedback(this.FeedbackID, this.feedback).subscribe(data => {
      console.log(data);
    }, error => console.log(error));
    this.feedback = new FeedBackData();
    this.gotoFeedback();
  }

 Delete(){
    this.appService.DeleteFeedbacks(this.FeedbackID).subscribe(data => {
      this.gotoFeedback();
    });
  }
  gotoFeedback() {
    this.router.navigate(['/Feedback']);
    this.getFeedback();
  }

 
}
