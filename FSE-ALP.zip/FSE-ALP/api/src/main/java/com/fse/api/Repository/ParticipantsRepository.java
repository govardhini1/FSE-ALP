package com.fse.api.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fse.api.entity.Participants;

@Repository
public interface ParticipantsRepository extends CrudRepository<Participants,String>{

}
