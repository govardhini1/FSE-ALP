import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedBackData } from '../shared/Models/FeedBack';
import { AppServiceService } from '../app-service.service';
import { Enrollments } from '../shared/Models/Enrollments';

@Component({
  selector: 'app-addfeedback',
  templateUrl: './addfeedback.component.html',
  styleUrls: ['./addfeedback.component.scss']
})
export class AddfeedbackComponent implements OnInit {

  ID  : number; 
  question : String;
  answer : String = '';
  feedbackType : String= '';
  FeedbackID:Number;
  public viewEnable : boolean = false;
  public QuestionDetails :any;
  public feedback : Enrollments [];
  public SelectedValue: String = '';
  Enrollmentdet : Enrollments  = new Enrollments();
 
  constructor(private router : Router, private appService: AppServiceService) { }

  ngOnInit() {
    this.getFeedback();
  }

  getFeedback() {
    // this.appService.getFeedbacks().subscribe(data => {
    //   this.feedbackDetails = data;
    //   console.log(this.feedbackDetails);
    // });
    this.appService.getQuestions().subscribe(data => {
        this.QuestionDetails = data;
        console.log(this.QuestionDetails);
      });
  }

  setRequest(){
    // this.feedbackdet = new FeedBackData();  
    // this.feedbackdet.question = this.feedbackdet['question']; 
    switch(this.SelectedValue) {
      case '1' :
          this.Enrollmentdet.enrollmentType = 'Participated';
          break;
      case '2' :
          this.Enrollmentdet.enrollmentType = 'Not Participated';
          break;
      case '3' :
          this.Enrollmentdet.enrollmentType = 'Unregistered';
          break;
    }
   
     console.log(this.Enrollmentdet.enrollmentType);
  }
  Cancel(){
    this.router.navigate(['Feedback']);
  }
  // Save(feedback : FeedBackData){
  //   // this.ID = feedback.id; 
  //   // console.log(feedback.id);
  //   console.log(this.SelectedValue);
  //    this.appService.editFeedback(feedback).subscribe(data => {
  //    this.getFeedback();
  //    this.ID = null;
  //    this.question = '';
  //    this.answer = '';
  //    this.feedbackType = '';
  //    });
  //  }
  
  Save(){
    this.setRequest();
    // this.appService.createFeedbacks(this.feedbackdet).subscribe(data =>  {
    //   this.feedbackdet = new FeedBackData(); 
    //   this.gotofeedback();  
    //   console.log(data) ,
    //   error => console.log(error)
    // });

    this.appService.createQuestions(this.Enrollmentdet).subscribe(data =>  {
      this.Enrollmentdet = new Enrollments(); 
        this.getFeedback();
      // this.gotofeedback();  
      console.log(data) ,
      error => console.log(error)
    });
    // this.feedbackdet.question = this.feedbackdet['question']; 
  
    }

    DeleteQuestions(id : Number) {
      this.appService.DeleteQuestions(id).subscribe(data => {
        this.getFeedback();
        console.log(data);
      });
    }
    
    gotofeedback(){
      this.router.navigate(['/Feedback']);
      this.getFeedback();
    }

    refresh() {
      this.viewEnable = true;
    }
}
