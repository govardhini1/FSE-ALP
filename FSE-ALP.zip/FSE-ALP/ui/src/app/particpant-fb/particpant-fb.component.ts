import { Component, OnInit } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { FeedBackData } from '../shared/Models/FeedBack';
import { Enrollments } from '../shared/Models/Enrollments';

@Component({
  selector: 'app-particpant-fb',
  templateUrl: './particpant-fb.component.html',
  styleUrls: ['./particpant-fb.component.scss']
})
export class ParticpantFbComponent implements OnInit {

  public feedbackDetails : Enrollments[] = [];
  public feedbacks : FeedBackData[] = [];
  public eventDetails :any;
  public participantsDetails :any;
  public answer : any = [];
  public smiley: any;
  public Question : String = 'How do you rate the overall event?	';
  feedbackdet : FeedBackData  = new FeedBackData();
  public questionDetails = [];
  private find :  boolean = false;
  private count = 0;

  constructor(private appService: AppServiceService) { }

  ngOnInit() {
    console.log(this.Question);
    // this.appService.getQuestions().subscribe(data => {
    //   this.QuestionDetails = data;
    //   console.log(this.QuestionDetails);
    // });
    this.appService.getQuestions().subscribe(data => {
      // this.Question = data[0].questions;
    data.forEach(element=> {
      if(element.enrollmentType ===  'Participated') {
        console.log(element.enrollmentType);
          this.feedbackDetails.push(element);
          console.log(this.Question);
          }
    });
     
    });
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
    });

    this.getquestions();
  }

  // setRequest(){
  //   this.feedbackDetails.forEach(element => {
  //   //   if(this.feedbackdet.question === element.question) {
  //   //     console.log(element.feedbackType);
  //   //       console.log(this.Question);
  //   //       this.feedbackdet.feedbackType = 'Participated';
  //   //       this.feedbackdet.answer = this.answer;
  //   //       this.feedbackdet.question = this.Question;
  //   //       }

  //   if(element.feedbackType ===  'Participated') {
  //     this.feedbackdet.feedbackType = 'Participated';
  //     this.feedbackdet.answer = element.answer;
  //     this.feedbackdet.question = element.question;
  //   }
  //   });
  // }

  icons(value){
    console.log(value, "hi");
    this.smiley = value;
    console.log( this.smiley, "hello");
  }

  submit() {
    //this.feedbackDetails.push(this.feedbackdet);
    console.log(this.feedbackDetails)
    //this.feedbackdet = new FeedBackData(); 
    this.feedbackDetails.forEach((element, index)=> {
      console.log(this.Question);
      console.log(element.questions, index)
      // if(element.question == this.Question) {
      //     console.log(element.question);
      //     this.feedbackdet.question = this.Question;
      //     this.feedbackdet.feedbackType = 'Participated';
      //     this.feedbackdet.answer = element.answer;
      //     }
      if(element.enrollmentType ===  'Participated') {
       
        this.feedbackdet.feedbackType = 'Participated';
        this.feedbackdet.answer = this.answer[index];
        this.feedbackdet.question = element.questions;
        if(element.questions == this.Question) 
        {
          this.feedbackdet.feedbackType = 'Participated';
          this.feedbackdet.answer = this.smiley;
          this.feedbackdet.question = this.Question;
          console.log(this.feedbackdet);
        }
        
      }
      console.log(this.feedbackdet);
      this.appService.createFeedbacks(this.feedbackdet).subscribe(data =>  {
        this.feedbackdet = new FeedBackData(); 
        console.log(data) ,
        error => console.log(error)
      });
    });
  }
  
  getquestions() {
    this.appService.getFeedbacks().subscribe(data => {
    data.forEach((element,index) => {
      if(element.feedbackType ===  'Participated') {
        this.feedbacks.push(element);
        console.log(this.feedbacks);
        // if( this.questionDetails.indexOf(this.feedbacks[index]) === -1) {
        //   console.log(this.feedbacks[index]);
        //   this.questionDetails.push(this.feedbacks[index]);
        //   console.log(this.questionDetails);
        // }
          }
    });
    for(let i =0; i < this.feedbacks.length; i++) {
      console.log(this.feedbacks[i]);
      for(let j =0; j < this.questionDetails.length; j++){
        if(this.feedbacks[i].question == this.questionDetails[j].question){
          this.find = true;
        }
      }
      this.count++;
      if(this.count == 1 && this.find == false){
      this.questionDetails.push(this.feedbacks[i]);
      console.log(this.questionDetails);
      }
      this.count = 0;
      this.find = false;
      // console.log(this.questionDetails);
      // if(this.questionDetails.indexOf(this.feedbacks[i]) === -1){
      //   this.questionDetails.push(this.feedbacks[i]);
      //     console.log(this.questionDetails);
      // }
    
    }
   
  });

  }
  // if( this.feedbackDetails.indexOf(element[index]) === -1) {
  //   console.log(this.feedbackDetails.push(element[index]));
  // }

  }


 // switch(element.questions) {
        //   case this.Question :
        //     this.feedbackdet.feedbackType = 'Participated';
        //       this.feedbackdet.answer = this.smiley;
        //       this.feedbackdet.question = this.Question;
        //       console.log(this.feedbackdet);
        //       this.appService.createFeedbacks(this.feedbackdet).subscribe(data =>  {
        //         this.feedbackdet = new FeedBackData(); 
        //         console.log(data) ,
        //         error => console.log(error)
        //       });
        //     case this.feedbackdet.question :
        //       this.feedbackdet.answer = this.answer[index];
        //        this.feedbackdet.question = element.questions;
        //        this.feedbackdet.feedbackType = 'Participated';
        //        console.log(this.feedbackdet);
        //        this.appService.createFeedbacks(this.feedbackdet).subscribe(data =>  {
        //          this.feedbackdet = new FeedBackData(); 
        //          console.log(data) ,
        //          error => console.log(error)
        //        });
        // }