package com.fse.api.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fse.api.entity.EventSummary;

@Repository
public interface EventSummaryRepository extends CrudRepository<EventSummary,String>{

}
