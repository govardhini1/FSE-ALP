package com.fse.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "Participants")
@EntityListeners(AuditingEntityListener.class)
public class Participants {

	public Participants() {
		// TODO Auto-generated constructor stub
	}
	@Id
    // @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Event_ID", nullable = false)
    private String id;
	
    @Column(name = "Base_Location", nullable = false)
    private String Base_Location;
    
    @Column(name = "BeneficiaryName", nullable = false)
    private String BeneficiaryName;
    
    @Column(name = "CouncilName", nullable = false)
    private String CouncilName;
    
    @Column(name = "EventName", nullable = false)
    private String EventName;
    	
    @Column(name = "EventDescription", nullable = false)
    private String EventDescription;
    
    @Column(name = "EventDate", nullable = false)
    private String EventDate;
    
    @Column(name = "Employee_ID", nullable = false)
    private String Employee_ID;
    
    @Column(name = "Employee_Name", nullable = false)
    private String Employee_Name;
    
    @Column(name = "Volunteer_Hours", nullable = false)
    private int Volunteer_Hours;
    
    @Column(name = "Travel_Hours", nullable = false)
    private int Travel_Hours;
    
    @Column(name = "Lives_Impacted", nullable = false)
    private int Lives_Impacted;
    
    @Column(name = "Business_Unit", nullable = false)
    private String Business_Unit;
    
    @Column(name = "Status", nullable = false)
    private String Status;
    
    @Column(name = "IIEP_Category", nullable = false)
    private String IIEP_Category;
    
    @Column(name = "Email_Id", nullable = false)
    private String Email_Id;
    
    @Column(name = "Enrollment", nullable = false)
    private String enrollment;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the base_Location
	 */
	public String getBase_Location() {
		return Base_Location;
	}

	/**
	 * @param base_Location the base_Location to set
	 */
	public void setBase_Location(String base_Location) {
		Base_Location = base_Location;
	}

	/**
	 * @return the beneficiaryName
	 */
	public String getBeneficiaryName() {
		return BeneficiaryName;
	}

	/**
	 * @param beneficiaryName the beneficiaryName to set
	 */
	public void setBeneficiaryName(String beneficiaryName) {
		BeneficiaryName = beneficiaryName;
	}

	/**
	 * @return the councilName
	 */
	public String getCouncilName() {
		return CouncilName;
	}

	/**
	 * @param councilName the councilName to set
	 */
	public void setCouncilName(String councilName) {
		CouncilName = councilName;
	}

	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return EventName;
	}

	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		EventName = eventName;
	}

	/**
	 * @return the eventDescription
	 */
	public String getEventDescription() {
		return EventDescription;
	}

	/**
	 * @param eventDescription the eventDescription to set
	 */
	public void setEventDescription(String eventDescription) {
		EventDescription = eventDescription;
	}

	/**
	 * @return the eventDate
	 */
	public String getEventDate() {
		return EventDate;
	}

	/**
	 * @param eventDate the eventDate to set
	 */
	public void setEventDate(String eventDate) {
		EventDate = eventDate;
	}

	/**
	 * @return the employee_ID
	 */
	public String getEmployee_ID() {
		return Employee_ID;
	}

	/**
	 * @param employee_ID the employee_ID to set
	 */
	public void setEmployee_ID(String employee_ID) {
		Employee_ID = employee_ID;
	}

	/**
	 * @return the employee_Name
	 */
	public String getEmployee_Name() {
		return Employee_Name;
	}

	/**
	 * @param employee_Name the employee_Name to set
	 */
	public void setEmployee_Name(String employee_Name) {
		Employee_Name = employee_Name;
	}

	/**
	 * @return the volunteer_Hours
	 */
	public int getVolunteer_Hours() {
		return Volunteer_Hours;
	}

	/**
	 * @param volunteer_Hours the volunteer_Hours to set
	 */
	public void setVolunteer_Hours(int volunteer_Hours) {
		Volunteer_Hours = volunteer_Hours;
	}

	/**
	 * @return the travel_Hours
	 */
	public int getTravel_Hours() {
		return Travel_Hours;
	}

	/**
	 * @param travel_Hours the travel_Hours to set
	 */
	public void setTravel_Hours(int travel_Hours) {
		Travel_Hours = travel_Hours;
	}

	/**
	 * @return the lives_Impacted
	 */
	public int getLives_Impacted() {
		return Lives_Impacted;
	}

	/**
	 * @param lives_Impacted the lives_Impacted to set
	 */
	public void setLives_Impacted(int lives_Impacted) {
		Lives_Impacted = lives_Impacted;
	}

	/**
	 * @return the business_Unit
	 */
	public String getBusiness_Unit() {
		return Business_Unit;
	}

	/**
	 * @param business_Unit the business_Unit to set
	 */
	public void setBusiness_Unit(String business_Unit) {
		Business_Unit = business_Unit;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return Status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		Status = status;
	}

	/**
	 * @return the iIEP_Category
	 */
	public String getIIEP_Category() {
		return IIEP_Category;
	}

	/**
	 * @param iIEP_Category the iIEP_Category to set
	 */
	public void setIIEP_Category(String iIEP_Category) {
		IIEP_Category = iIEP_Category;
	}

	/**
	 * @return the email_Id
	 */
	public String getEmail_Id() {
		return Email_Id;
	}

	/**
	 * @param email_Id the email_Id to set
	 */
	public void setEmail_Id(String email_Id) {
		Email_Id = email_Id;
	}

	/**
	 * @return the enrollment
	 */
	public String getEnrollment() {
		return enrollment;
	}

	/**
	 * @param enrollment the enrollment to set
	 */
	public void setEnrollment(String enrollment) {
		this.enrollment = enrollment;
	}

	/**
	 * @param id
	 * @param base_Location
	 * @param beneficiaryName
	 * @param councilName
	 * @param eventName
	 * @param eventDescription
	 * @param eventDate
	 * @param employee_ID
	 * @param employee_Name
	 * @param volunteer_Hours
	 * @param travel_Hours
	 * @param lives_Impacted
	 * @param business_Unit
	 * @param status
	 * @param iIEP_Category
	 * @param email_Id
	 * @param enrollment
	 */
	public Participants(String id, String base_Location, String beneficiaryName, String councilName, String eventName,
			String eventDescription, String eventDate, String employee_ID, String employee_Name, int volunteer_Hours,
			int travel_Hours, int lives_Impacted, String business_Unit, String status, String iIEP_Category,
			String email_Id, String enrollment) {
		super();
		this.id = id;
		Base_Location = base_Location;
		BeneficiaryName = beneficiaryName;
		CouncilName = councilName;
		EventName = eventName;
		EventDescription = eventDescription;
		EventDate = eventDate;
		Employee_ID = employee_ID;
		Employee_Name = employee_Name;
		Volunteer_Hours = volunteer_Hours;
		Travel_Hours = travel_Hours;
		Lives_Impacted = lives_Impacted;
		Business_Unit = business_Unit;
		Status = status;
		IIEP_Category = iIEP_Category;
		Email_Id = email_Id;
		this.enrollment = enrollment;
	}

		
}