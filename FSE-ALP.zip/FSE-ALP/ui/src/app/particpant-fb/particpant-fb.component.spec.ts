import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticpantFbComponent } from './particpant-fb.component';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClient, HttpHandler, HttpClientModule } from '@angular/common/http';

describe('ParticpantFbComponent', () => {
  let component: ParticpantFbComponent;
  let fixture: ComponentFixture<ParticpantFbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticpantFbComponent ],
      imports: [
        FormsModule,
        HttpClientModule
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticpantFbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
