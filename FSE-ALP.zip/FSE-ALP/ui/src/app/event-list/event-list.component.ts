import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'
import { AppServiceService } from '../app-service.service';

@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.scss']
})
export class EventListComponent implements OnInit {

  public eventDetails: any;
  public participantsDetails: any;
  eventID:String
  eventByIDDetails : any
  constructor(private router: Router, private appService: AppServiceService, private route : ActivatedRoute) { }

  ngOnInit() {
    this.getEventDetails();
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
    });
    this.appService.getParticiants().subscribe(data => {
      this.participantsDetails = data;
      console.log(this.participantsDetails);
    })

  }

  viewEventDetail(eventData) {
    this.router.navigate(['/eventList',eventData.id]);
    this.eventID = this.route.snapshot.params['id'];
    // this.appService.getEventsById(this.eventID).subscribe(data => {
    //   this.eventByIDDetails = data;
    //   console.log(this.eventByIDDetails);
    // });
  }

  getEventDetails() {
    // this.appService.getEvents().subscribe(data => {
    //   this.eventDetails = data;
    //   console.log(this.eventDetails);
    // })
  }
}
