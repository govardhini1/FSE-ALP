export class Email {
    toAddress : string;
    messageBody : string;
}