import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotparticpatedFbComponent } from './notparticpated-fb.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';

describe('NotparticpatedFbComponent', () => {
  let component: NotparticpatedFbComponent;
  let fixture: ComponentFixture<NotparticpatedFbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotparticpatedFbComponent ],
      imports: [
        FormsModule
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotparticpatedFbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
