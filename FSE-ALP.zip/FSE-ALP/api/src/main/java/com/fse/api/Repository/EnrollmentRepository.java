package com.fse.api.Repository;

import org.springframework.data.repository.CrudRepository;

import com.fse.api.entity.Enrollment;


public interface EnrollmentRepository extends CrudRepository<Enrollment,Long>{

}
