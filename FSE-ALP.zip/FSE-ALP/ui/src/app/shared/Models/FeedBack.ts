export class FeedBackData {
id: number;
question: String;
answer: String;
feedbackType: String;
constructor() {
    this.id = null;
    this.question = '';
    this.answer = '';
    this.feedbackType = ''
}
}