import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppServiceService } from 'src/app/app-service.service';
import { Email } from '../Models/Email';
import { Participants } from '../Models/participants';

@Component({
  selector: 'app-action',
  templateUrl: './action.component.html',
  styleUrls: ['./action.component.scss']
})
export class ActionComponent implements OnInit {

  public currentUrl: string = '';
  public blueCardShow: boolean = true;
  public greenCardShow: boolean = false;
  public emailTemplate;
  public emailContent;
  email : Email  = new Email();
  //public participantsDetails: any;
  public participantsDetails : Participants[] = [];

  constructor(private route: ActivatedRoute, private appService: AppServiceService) {

    this.emailTemplate = '<div>Hello All, </div> \n <p> Please provide your valuable feedback by clicking below url</p> \n';
    this.emailContent = '\n <h4>Thanks & Regards,</h4>  \n  <h4>OutReach Team</h4>';
   }

  ngOnInit() {
    this.currentUrl = this.route.snapshot.url[0].path;
    console.log(this.currentUrl)
    if(this.currentUrl == 'Reports'){
      this.greenCardShow = true;
      this.blueCardShow = false;
    }
    this.appService.getParticiants().subscribe(data => {
      // this.participantsDetails = data;
      data.forEach(element => {
        this.participantsDetails.push(element);
        console.log(element);
        // this.participantsDetails.forEach(element => {
        // element.enrollment = '';
        // if(element.enrollment == "participated") {
        //   this.email.toAddress = element.emailId;
        //   console.log(this.email.toAddress)
        //   this.email.messageBody = this.emailTemplate + "http://localhost:4200/Participants" + this.emailContent;
        // } else if(element.enrollment == "Not participated") {
        //   this.email.toAddress = element.emailId;
        //   console.log(this.email.toAddress)
        //   this.email.messageBody = this.emailTemplate + "http://localhost:4200/NonParticipants" + this.emailContent;
        // } else{
        //   this.email.toAddress = element.emailId;
        //   console.log(this.email.toAddress)
        //   this.email.messageBody = this.emailTemplate + "http://localhost:4200/unregister" + this.emailContent;
        // }
        console.log(this.participantsDetails);
      })
     
    })
  }

  sendEmail(){
    console.log( this.participantsDetails)
        this.participantsDetails.forEach(element => {
          console.log(element)
          // switch(element.enrollment) {
          //   case 'unregistered' :
          //     this.email.toAddress = element.email_Id;
          //       console.log(  this.email.toAddress )
          //       this.email.messageBody = this.emailTemplate + "http://localhost:4200/unregister" + this.emailContent;
          //       this.appService.sendMail(this.email).subscribe(data => {
          //           this.email = new Email();
          //           console.log(data) ,
          //           error => console.log(error)
          //         });
          //       break;
          //   case 'Not participated' :
          //     this.email.toAddress = element.email_Id;
          //       console.log(this.email.toAddress)
          //       this.email.messageBody = this.emailTemplate + "http://localhost:4200/NonParticipants" + this.emailContent;
          //       this.appService.sendMail(this.email).subscribe(data => {
          //           this.email = new Email();
          //           console.log(data) ,
          //           error => console.log(error)
          //         });
          //       break;
          //   case 'participated' :
          //     this.email.toAddress = element.email_Id;
          //       console.log(this.email.toAddress)
          //       this.email.messageBody = this.emailTemplate + "http://localhost:4200/Participants" + this.emailContent;
          //       this.appService.sendMail(this.email).subscribe(data => {
          //           this.email = new Email();
          //           console.log(data) ,
          //           error => console.log(error)
          //         });
          //       break;
          // }
      if(element.enrollment === "unregistered") {
        this.email.toAddress = element.email_Id;
        console.log(element.enrollment)
        this.email.messageBody = this.emailTemplate + "http://localhost:4200/unregister" + this.emailContent;
        this.appService.sendMail(this.email).subscribe(data => {
          this.email = new Email();
          console.log(data) ,
          error => console.log(error)
        });
      } else if(element.enrollment === "Not participated") {
        this.email.toAddress = element.email_Id;
        console.log(this.email.toAddress)
        this.email.messageBody = this.emailTemplate + "http://localhost:4200/NonParticipants" + this.emailContent;
        this.appService.sendMail(this.email).subscribe(data => {
          this.email = new Email();
          console.log(data) ,
          error => console.log(error)
        });
      } else{
        this.email.toAddress = element.email_Id;
        console.log(this.email.toAddress)
        this.email.messageBody = this.emailTemplate + "http://localhost:4200/Participants" + this.emailContent;
        this.appService.sendMail(this.email).subscribe(data => {
          this.email = new Email();
          console.log(data) ,
          error => console.log(error)
        });
       }
    }) 
  
  }

//   sendEmail(){
//     this.setRequest();
//     this.appService.sendMail(this.email).subscribe(data => {
//       this.email = new Email();
//       console.log(data) ,
//       error => console.log(error)
//     });
    
//     console.log("hi");
// }

}
