import { TestBed } from '@angular/core/testing';

import { AuthGaurdService } from './auth-gaurd.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHandler } from '@angular/common/http';

describe('AuthGaurdService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [HttpClient, HttpHandler,{ 
      provide: Router, 
      useClass: class { navigate = jasmine.createSpy("navigate"); }
  }]
  }));

  it('should be created', () => {
    const service: AuthGaurdService = TestBed.get(AuthGaurdService);
    expect(service).toBeTruthy();
  });
});
