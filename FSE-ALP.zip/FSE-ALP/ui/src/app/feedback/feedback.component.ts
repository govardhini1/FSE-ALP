import { Component, OnInit } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { FeedBackData } from '../shared/Models/FeedBack';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit {

  public feedbackShow: boolean = true;
  public addQuestShow: boolean = false;
  public editQuestShow: boolean = false;
  public addAnsShow: boolean = false;
  public feedbackDetails :any;
  public feedback : FeedBackData [];
  public SelectedValue: String ;
  ID  =null; 
  question : String= '';
  answer : String = '';
  feedbackType : String= '';
  FeedbackID:Number;

  constructor(private appService: AppServiceService, private route : ActivatedRoute, private router : Router) { }

  ngOnInit() {
  //  this.feedback = new FeedBackData();
  setTimeout( () => {
    this.getFeedback();
  }, 1000) 
   
   
  
  
  }

  AddQuestion() {
    this.router.navigate(['addfeedback']);
  }
  getFeedback() {
  this.appService.getFeedbacks().subscribe(data => {
    this.feedbackDetails = data;
    console.log(this.feedbackDetails);
  });
}
  editQuestion(feedback){
    this.router.navigate(['editfeedback', feedback.id]);
    this.FeedbackID = this.route.snapshot.params['id'];
    console.log(this.FeedbackID);
    // this.appService.getFeedbacks().subscribe(data => {
    //   this.feedbackDetails = data;
    //   console.log(this.feedbackDetails);
    // });
    // this.appService.getFeedbacksById(id).subscribe(feedback => {
    //   console.log(feedback);
    //   this.ID = feedback.id;
    //   this.question = feedback.question;
    //   this.answer = feedback.answer;
    //   this.feedbackType = feedback.feedbackType;
    // })
  }
  // editSave(id : Number) {
  //   this.appService.getFeedbacksById(id).subscribe(feedback => {
  //     console.log(feedback);
  //     this.ID = feedback.id;
  //     this.question = feedback.question;
  //     this.answer = feedback.answer;
  //     this.feedbackType = feedback.feedbackType;
  //   })
  // }

  

  addAnswer(){
    this.addAnsShow = true;
  }

  // Save(feedback : FeedBackData){
  //  feedback.id = this.ID; 
  //  console.log(feedback.id);
  //  console.log(this.SelectedValue);
  //   this.appService.upateFeedback(feedback).subscribe(data => {
  //   this.getFeedback();
  //   this.ID = null;
  //   this.question = '';
  //   this.answer = '';
  //   this.feedbackType = '';
  //   });
 // }
  
  // Delete(id : number) {
  //   this.appService.DeleteFeedbacks(id).subscribe(data => {
  //  //   this.eventByIDDetails = data;
  //     console.log(data);
  //   });
  // }

}
