import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionComponent } from './action.component';
import { ActivatedRoute, convertToParamMap } from '@angular/router';
import { of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';

describe('ActionComponent', () => {
  let component: ActionComponent;
  let fixture: ComponentFixture<ActionComponent>;

  beforeEach(async(() => {
  //   const fakeActivatedRoute = {
  //     snapshot: { data: {id: 0} }
  // }  
      TestBed.configureTestingModule({
      declarations: [ ActionComponent ],
      imports : [ HttpClientModule],
      providers: [ { provide: ActivatedRoute, useValue: {
        paramMap: of( convertToParamMap( { id: 0 } ) ), url:[{path : {}}]
    }
}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
