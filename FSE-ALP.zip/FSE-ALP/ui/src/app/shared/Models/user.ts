export class User {
    id : Number;
    role : String;
    email : String;
    password : String;
    constructor() {
        
    }
}