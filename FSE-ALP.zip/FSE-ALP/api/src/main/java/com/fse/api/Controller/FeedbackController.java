package com.fse.api.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fse.api.Repository.FeedbackRepository;
import com.fse.api.entity.Feedback;



@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/")
public class FeedbackController {

	@Autowired
	  private FeedbackRepository feedbackRepository;

	 @GetMapping("/Feedback")
	  public List<Feedback> getAllEvents() {
	    return (List<Feedback>) feedbackRepository.findAll();
	  }
	 @GetMapping("/Feedback/{id}")
	  public Optional<Feedback> getFeedbackById(@PathVariable long id) {
		 return feedbackRepository.findById(id);
	  }
	  @PostMapping(path="/addFeedback" ,consumes = "application/json", produces = "application/json")
	  public @ResponseBody Feedback createUser(@RequestBody Feedback feedback) {
	  feedbackRepository.save(feedback);
	  return feedback;
	  }
	  @PutMapping(path="/updateFeedback/{id}",consumes = "application/json", produces = "application/json")
	  public String updateeFeedback(@RequestBody Feedback feedback,@PathVariable long id) {
		 feedbackRepository.findById(id);
		 feedback.setId(id);
		 feedback.setQuestion(feedback.getQuestion());
		 feedback.setAnswer(feedback.getAnswer());
		 feedback.setFeedbackType(feedback.getFeedbackType());
	  feedbackRepository.save(feedback);
	  return "feedback updated Successfully!" + feedback.getId() + " " + feedback.getQuestion() + "" + feedback.getAnswer();
	  }
	  @DeleteMapping("/deleteFeedback/{id}")
	  public String deleteFeedback(@PathVariable long id) {
		  feedbackRepository.deleteById(id);
	  return "feedbackDetails deleted Successfully!";
	  }
}
