create database fse;
use fse;

create table users(id int(50) PRIMARY KEY, email_address varchar(100), password varchar(50),Role varchar(50));

alter table users drop column first_name;

alter table users add Role varchar(40);

alter table users add primary key(id);

update users set Role='Participants' where id=1;

select * from users;

insert into users values(1,'abi@g');

insert into users values(2,'abi@g');

insert into users values(4,'Hariram@cog.com','hari12','POC');

delete from users where id=0;