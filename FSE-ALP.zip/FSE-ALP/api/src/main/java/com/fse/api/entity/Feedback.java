package com.fse.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "Feedback")
@EntityListeners(AuditingEntityListener.class)
public class Feedback {

	public Feedback() {
		// TODO Auto-generated constructor stub
	}
	  @Id
	    // @GeneratedValue(strategy = GenerationType.AUTO)
	  @Column(name = "Feedback_ID", nullable = false)
	    private long id;
	    @Column(name = "Question", nullable = false)
	    private String question;
	    @Column(name = "Answer", nullable = false)
	    private String answer;
	    @Column(name = "Feedback_Type", nullable = false)
	    private String FeedbackType;
		/**
		 * @return the id
		 */
		public long getId() {
			return id;
		}
		/**
		 * @param id the id to set
		 */
		public void setId(long id) {
			this.id = id;
		}
		/**
		 * @return the question
		 */
		public String getQuestion() {
			return question;
		}
		/**
		 * @param question the question to set
		 */
		public void setQuestion(String question) {
			this.question = question;
		}
		/**
		 * @return the answer
		 */
		public String getAnswer() {
			return answer;
		}
		/**
		 * @param answer the answer to set
		 */
		public void setAnswer(String answer) {
			this.answer = answer;
		}
		/**
		 * @return the feedbackType
		 */
		public String getFeedbackType() {
			return FeedbackType;
		}
		/**
		 * @param feedbackType the feedbackType to set
		 */
		public void setFeedbackType(String feedbackType) {
			FeedbackType = feedbackType;
		}
		/**
		 * @param id
		 * @param question
		 * @param answer
		 * @param feedbackType
		 */
		public Feedback(long id, String question, String answer, String feedbackType) {
			super();
			this.id = id;
			this.question = question;
			this.answer = answer;
			FeedbackType = feedbackType;
		}
	    
}
