package com.fse.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "Event_Summary")
@EntityListeners(AuditingEntityListener.class)
public class EventSummary {

	@Id
    // @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Event_ID", nullable = false)
    private String id;
    @Column(name = "Month", nullable = false)
    private String Month;
    @Column(name = "Base_Location", nullable = false)
    private String BaseLocation;
    @Column(name = "BeneficiaryName", nullable = false)
    private String BeneficiaryName;
    @Column(name = "Venue_Address", nullable = false)
    private String VenueAddress;
    @Column(name = "CouncilName", nullable = false)
    private String Council_Name;
    @Column(name = "Project", nullable = false)
    private String Project;
    @Column(name = "Category", nullable = false)
    private String Category;
    @Column(name = "EventName", nullable = false)
    private String EventName;
    @Column(name = "EventDescription", nullable = false)
    private String EventDescription;
    @Column(name = "EventDate", nullable = false)
    private String EventDate;
    @Column(name = "Total_No_of_volunteers", nullable = false)
    private int TotalVolunteers;
    @Column(name = "Total_Volunteer_Hours", nullable = false)
    private int TotalVolunteerHours;
    @Column(name = "Total_Travel_Hours", nullable = false)
    private int TotalTravelHours;
    @Column(name = "Overall_Volunteering_Hours", nullable = false)
    private int OverallVolunteeringHours;
    @Column(name = "Lives_Impacted", nullable = false)
    private int LivesImpacted;
    @Column(name = "Activity_Type", nullable = false)
    private int ActivityType;
    @Column(name = "Status", nullable = false)
    private String Status;
    @Column(name = "POC_ID", nullable = false)
    private long POCID;
    @Column(name = "POC_Name", nullable = false)
    private String POCName;
    @Column(name = "POC_Contact_Number", nullable = false)
    private long POCContactNumber;
   
    
	public EventSummary() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param id
	 * @param month
	 * @param baseLocation
	 * @param beneficiaryName
	 * @param venueAddress
	 * @param council_Name
	 * @param project
	 * @param category
	 * @param eventName
	 * @param eventDescription
	 * @param eventDate
	 * @param totalVolunteers
	 * @param totalVolunteerHours
	 * @param totalTravelHours
	 * @param overallVolunteeringHours
	 * @param livesImpacted
	 * @param activityType
	 * @param status
	 * @param pOCID
	 * @param pOCName
	 * @param pOCContactNumber
	 */
	public EventSummary(String id, String month, String baseLocation, String beneficiaryName, String venueAddress,
			String council_Name, String project, String category, String eventName, String eventDescription,
			String eventDate, int totalVolunteers, int totalVolunteerHours, int totalTravelHours,
			int overallVolunteeringHours, int livesImpacted, int activityType, String status, long pOCID,
			String pOCName, long pOCContactNumber) {
		super();
		this.id = id;
		Month = month;
		BaseLocation = baseLocation;
		BeneficiaryName = beneficiaryName;
		VenueAddress = venueAddress;
		Council_Name = council_Name;
		Project = project;
		Category = category;
		EventName = eventName;
		EventDescription = eventDescription;
		EventDate = eventDate;
		TotalVolunteers = totalVolunteers;
		TotalVolunteerHours = totalVolunteerHours;
		TotalTravelHours = totalTravelHours;
		OverallVolunteeringHours = overallVolunteeringHours;
		LivesImpacted = livesImpacted;
		ActivityType = activityType;
		Status = status;
		POCID = pOCID;
		POCName = pOCName;
		POCContactNumber = pOCContactNumber;
	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the month
	 */
	public String getMonth() {
		return Month;
	}


	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		Month = month;
	}


	/**
	 * @return the baseLocation
	 */
	public String getBaseLocation() {
		return BaseLocation;
	}


	/**
	 * @param baseLocation the baseLocation to set
	 */
	public void setBaseLocation(String baseLocation) {
		BaseLocation = baseLocation;
	}


	/**
	 * @return the beneficiaryName
	 */
	public String getBeneficiaryName() {
		return BeneficiaryName;
	}


	/**
	 * @param beneficiaryName the beneficiaryName to set
	 */
	public void setBeneficiaryName(String beneficiaryName) {
		BeneficiaryName = beneficiaryName;
	}


	/**
	 * @return the venueAddress
	 */
	public String getVenueAddress() {
		return VenueAddress;
	}


	/**
	 * @param venueAddress the venueAddress to set
	 */
	public void setVenueAddress(String venueAddress) {
		VenueAddress = venueAddress;
	}


	/**
	 * @return the council_Name
	 */
	public String getCouncil_Name() {
		return Council_Name;
	}


	/**
	 * @param council_Name the council_Name to set
	 */
	public void setCouncil_Name(String council_Name) {
		Council_Name = council_Name;
	}


	/**
	 * @return the project
	 */
	public String getProject() {
		return Project;
	}


	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		Project = project;
	}


	/**
	 * @return the category
	 */
	public String getCategory() {
		return Category;
	}


	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		Category = category;
	}


	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return EventName;
	}


	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		EventName = eventName;
	}


	/**
	 * @return the eventDescription
	 */
	public String getEventDescription() {
		return EventDescription;
	}


	/**
	 * @param eventDescription the eventDescription to set
	 */
	public void setEventDescription(String eventDescription) {
		EventDescription = eventDescription;
	}


	/**
	 * @return the eventDate
	 */
	public String getEventDate() {
		return EventDate;
	}


	/**
	 * @param eventDate the eventDate to set
	 */
	public void setEventDate(String eventDate) {
		EventDate = eventDate;
	}


	/**
	 * @return the totalVolunteers
	 */
	public int getTotalVolunteers() {
		return TotalVolunteers;
	}


	/**
	 * @param totalVolunteers the totalVolunteers to set
	 */
	public void setTotalVolunteers(int totalVolunteers) {
		TotalVolunteers = totalVolunteers;
	}


	/**
	 * @return the totalVolunteerHours
	 */
	public int getTotalVolunteerHours() {
		return TotalVolunteerHours;
	}


	/**
	 * @param totalVolunteerHours the totalVolunteerHours to set
	 */
	public void setTotalVolunteerHours(int totalVolunteerHours) {
		TotalVolunteerHours = totalVolunteerHours;
	}


	/**
	 * @return the totalTravelHours
	 */
	public int getTotalTravelHours() {
		return TotalTravelHours;
	}


	/**
	 * @param totalTravelHours the totalTravelHours to set
	 */
	public void setTotalTravelHours(int totalTravelHours) {
		TotalTravelHours = totalTravelHours;
	}


	/**
	 * @return the overallVolunteeringHours
	 */
	public int getOverallVolunteeringHours() {
		return OverallVolunteeringHours;
	}


	/**
	 * @param overallVolunteeringHours the overallVolunteeringHours to set
	 */
	public void setOverallVolunteeringHours(int overallVolunteeringHours) {
		OverallVolunteeringHours = overallVolunteeringHours;
	}


	/**
	 * @return the livesImpacted
	 */
	public int getLivesImpacted() {
		return LivesImpacted;
	}


	/**
	 * @param livesImpacted the livesImpacted to set
	 */
	public void setLivesImpacted(int livesImpacted) {
		LivesImpacted = livesImpacted;
	}


	/**
	 * @return the activityType
	 */
	public int getActivityType() {
		return ActivityType;
	}


	/**
	 * @param activityType the activityType to set
	 */
	public void setActivityType(int activityType) {
		ActivityType = activityType;
	}


	/**
	 * @return the status
	 */
	public String getStatus() {
		return Status;
	}


	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		Status = status;
	}


	/**
	 * @return the pOCID
	 */
	public long getPOCID() {
		return POCID;
	}


	/**
	 * @param pOCID the pOCID to set
	 */
	public void setPOCID(long pOCID) {
		POCID = pOCID;
	}


	/**
	 * @return the pOCName
	 */
	public String getPOCName() {
		return POCName;
	}


	/**
	 * @param pOCName the pOCName to set
	 */
	public void setPOCName(String pOCName) {
		POCName = pOCName;
	}


	/**
	 * @return the pOCContactNumber
	 */
	public long getPOCContactNumber() {
		return POCContactNumber;
	}


	/**
	 * @param pOCContactNumber the pOCContactNumber to set
	 */
	public void setPOCContactNumber(long pOCContactNumber) {
		POCContactNumber = pOCContactNumber;
	}
	
	

}
