import { Component, OnInit, Input } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { Router } from '@angular/router';
import { filter } from 'minimatch';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public eventDetails: any;
  public participantsDetails: any;
  public livesImpacted  : any = 0;
  public TotalEvents  : any;
  public TotalVolunteers  : any = 0;
  public TotalParticipants  : any = 0;
  constructor(private router: Router, private appService: AppServiceService) { }

 // @Input() childMessage: String;
  public user : any;
  public role : String;
  
  ngOnInit() {
    this.appService.getUsers().subscribe(Response => {
      this.user = Response;
      console.log(this.user);
      console.log(sessionStorage.getItem('username'))
      this.user.forEach((element : any) => {
        let userName = sessionStorage.getItem('username');
        if(userName == element.email) {
          this.role = element.role;
             console.log(this.role);
        }
        
      })
    }) 
  //   this.appService.getUsers().subscribe(Response => {
  //     this.user = Response;
  //     this.user.forEach((element : any) => {
  //       if(this.childMessage == element.password) {
  //         this.role = element.role;
  //            console.log(element.role);
  //       }
        
  //     })
  // })
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
      this.eventDetails.forEach((element : any) => {
        this.livesImpacted  += element.livesImpacted;
        this.TotalEvents  = this.eventDetails.length;
        this.TotalVolunteers += element.totalVolunteers;
        console.log(this.livesImpacted);
        console.log(this.TotalEvents);
        console.log(this.TotalVolunteers);
      });
    });
    this.appService.getParticiants().subscribe(data => {
      this.participantsDetails = data;
      console.log(this.participantsDetails);
      //  this.participantsDetails.forEach((element : any) => {
      //   this.TotalParticipants = (element.length);
      //    console.log(this.TotalParticipants);
      //  });
    //  for(let i = 0 ; i< this.participantsDetails.length; i++) {
        this.TotalParticipants = (this.participantsDetails.length);
       console.log(this.TotalParticipants);
    //  }
    })
  
  }

}
