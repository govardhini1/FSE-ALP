import { Component, OnInit } from '@angular/core';
import { FeedBackData } from '../shared/Models/FeedBack';
import { AppServiceService } from '../app-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-unregistered-fb',
  templateUrl: './unregistered-fb.component.html',
  styleUrls: ['./unregistered-fb.component.scss']
})
export class UnregisteredFbComponent implements OnInit {

  public feedbackDetails : FeedBackData[] = [];
  public eventDetails :any;
  public participantsDetails :any;
  feedbackdet : FeedBackData  = new FeedBackData();
  public selectedAnswer : string;
  public selectedButton : string = '';
  public Question : String;

  constructor(private appService: AppServiceService,  private router: Router) { }

  ngOnInit() {
    this.appService.getFeedbacks().subscribe(data => {
    data.forEach(element => {
      if(element.feedbackType ===  'Unregistered') {
        console.log(element.feedbackType);
        this.Question = element.question;
          this.feedbackDetails.push(element);
          console.log(this.feedbackDetails);
          }
    });
     
    });
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
    });
  }

  answers(event) {
    this.selectedButton = event.target.id; 
    this.selectedAnswer = event.target.value;
    console.log(this.selectedButton);
    console.log(  this.selectedAnswer);
  }

  submit() {
    this.feedbackDetails.forEach(e => {
      if(e.feedbackType ===  'Unregistered') {
          this.feedbackdet.question = e.question;
      }
    });
    this.feedbackdet.feedbackType = 'Unregistered';
    this.feedbackdet.answer = this.selectedAnswer;
    console.log(this.feedbackdet)
    this.appService.createFeedbacks(this.feedbackdet).subscribe(data =>  {
      this.feedbackdet = new FeedBackData(); 
      console.log(data) ,
      error => console.log(error)
    });
    this.router.navigate(['/InfoScreen']);
  }

  Reset(){
    this.selectedButton = ''; 
  }
}
