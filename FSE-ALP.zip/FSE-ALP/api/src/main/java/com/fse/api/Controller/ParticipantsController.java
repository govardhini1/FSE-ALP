package com.fse.api.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fse.api.Repository.ParticipantsRepository;
import com.fse.api.entity.Participants;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/")
public class ParticipantsController {

	@Autowired
	  private ParticipantsRepository participantsRepository;

	 @GetMapping("/Participants")
	  public List<Participants> getAllParticipants() {
	    return (List<Participants>) participantsRepository.findAll();
	  }
	 @GetMapping("/Participants/{id}")
	  public Optional<Participants> getParticipants(@PathVariable String id) {
		 return participantsRepository.findById(id);
	  }

}
