package com.fse.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "Enrollment")
@EntityListeners(AuditingEntityListener.class)
public class Enrollment {

	public Enrollment() {
		// TODO Auto-generated constructor stub
	}

	 @Id
	    // @GeneratedValue(strategy = GenerationType.AUTO)
	  @Column(name = "Question_ID", nullable = false)
	    private long id;
	    @Column(name = "Questions", nullable = false)
	    private String questions;
	    @Column(name = "Enrollment_Type", nullable = false)
	    private String EnrollmentType;
		/**
		 * @return the id
		 */
		public long getId() {
			return id;
		}
		/**
		 * @param id the id to set
		 */
		public void setId(long id) {
			this.id = id;
		}
		/**
		 * @return the questions
		 */
		public String getQuestions() {
			return questions;
		}
		/**
		 * @param questions the questions to set
		 */
		public void setQuestions(String questions) {
			this.questions = questions;
		}
		/**
		 * @return the enrollmentType
		 */
		public String getEnrollmentType() {
			return EnrollmentType;
		}
		/**
		 * @param enrollmentType the enrollmentType to set
		 */
		public void setEnrollmentType(String enrollmentType) {
			EnrollmentType = enrollmentType;
		}
		/**
		 * @param id
		 * @param questions
		 * @param enrollmentType
		 */
		public Enrollment(long id, String questions, String enrollmentType) {
			super();
			this.id = id;
			this.questions = questions;
			EnrollmentType = enrollmentType;
		}

	    
}
