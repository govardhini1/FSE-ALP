import { Component, OnInit } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { Role } from '../shared/Models/Roles';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.scss']
})
export class RolesComponent implements OnInit {
  public pmoDetails : any;
  pmos : Role  = new Role();

  constructor(private appService: AppServiceService) { }

  ngOnInit() {
   this.getpmodetails();
  }

  getpmodetails(){
    this.appService.getPmoDetails().subscribe(data => {
      this.pmoDetails = data;
      console.log(this.pmoDetails);
    });
  }
  addPmo(){
    this.pmos.role = 'Pmo';
    this.appService.createPmos(this.pmos).subscribe(data =>  {
      this.pmos = new Role(); 
      this.getpmodetails();
      // this.gotofeedback();  
      console.log(data) ,
      error => console.log(error)
    });
  }

  DeletePmodetails(id : Number) {
    this.appService.DeletePmos(id).subscribe(data => {
      this.getpmodetails();
      console.log(data);
    });
  }
}
