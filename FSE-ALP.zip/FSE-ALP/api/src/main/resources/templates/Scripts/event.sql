create table Event_Summary(Event_ID varchar(20) PRIMARY KEY, Month varchar(15), Base_Location varchar(50),BeneficiaryName varchar(100),Venue_Address varchar(300),
Council_Name varchar(100),Project varchar(100),Category varchar(100),EventName varchar(100),EventDescription varchar(400),EventDate varchar(50),Total_No_of_volunteers int(50),
Total_Volunteer_Hours int(50),Total_Travel_Hours int(50),Overall_Volunteering_Hours int(50),Lives_Impacted int(50),Activity_Type int(50),Status varchar(50),
POC_ID int(10),POC_Name varchar(50),POC_Contact_Number bigint(10));


select * from Event_Summary;

ALTER TABLE Event_Summary
MODIFY  COLUMN POC_Contact_Number bigint(15);

update Event_Summary set POC_Contact_Number=9876532134 where Event_ID='EVNT00047261';



create table Event_Summary(Event_ID varchar(20) PRIMARY KEY, Month varchar(15), Base_Location varchar(200),BeneficiaryName varchar(100),Venue_Address varchar(300),
Council_Name varchar(100),Project varchar(100),Category varchar(100),EventName varchar(100),EventDescription varchar(400),EventDate varchar(50),Total_No_of_volunteers int(50),
Total_Volunteer_Hours int(50),Total_Travel_Hours int(50),Overall_Volunteering_Hours int(50),Lives_Impacted int(50),Activity_Type int(50),Status varchar(50),
POC_ID int(10),POC_Name varchar(50),POC_Contact_Number bigint(10));

create table Participants(Event_ID varchar(20) PRIMARY KEY,Base_Location varchar(200),BeneficiaryName varchar(100),CouncilName varchar(200),EventName varchar(300),EventDescription varchar(1000),EventDate varchar(20),Employee_ID int(10),Employee_Name varchar(100),Volunteer_Hours int(50),Travel_Hours int(50),Lives_Impacted int(50),Business_Unit varchar(200),Status varchar(50),IIEP_Category varchar(100));

ALTER TABLE Participants
MODIFY  COLUMN BeneficiaryName varchar(300);

select * from Participants;

use fse;
