import { Injectable } from '@angular/core';
import { AppServiceService } from 'src/app/app-service.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  public user : any;
  public role : any;
  public roleCheck : boolean = false;

  constructor(private appservice : AppServiceService, private router : Router) {
   
   }

  

  authenticate(username, password) {
  this.appservice.getUsers().subscribe(Response => {
    this.user = Response;
    console.log(this.user);
    this.user.forEach((element : any) => {
    console.log(element.email)
      if(username === element.email && password === element.password) {
        sessionStorage.setItem('username', username);
        let userName = sessionStorage.getItem('username');
        if(userName == element.email) {
          this.role = element.role;
          if(this.role == 'Admin' || this.role == 'Pmo' || this.role == 'Poc'){
            this.router.navigate(['dashboard']);
          }  else {
            this.router.navigate(['Participants']);
          }
        }
      
        return true;
      } else {
        return false;

      }
    })
  })
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}


