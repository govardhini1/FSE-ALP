import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppServiceService } from '../app-service.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  public eventDetails: any;
  public participantsDetails: any;
  constructor(private router: Router, private appService: AppServiceService) { }

  ngOnInit() {
    this.appService.getEvents().subscribe(data => {
      this.eventDetails = data;
      console.log(this.eventDetails);
    });
    this.appService.getParticiants().subscribe(data => {
      this.participantsDetails = data;
      console.log(this.participantsDetails);
    })

  }

}
