import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { AppServiceService } from '../app-service.service';
import { User } from '../shared/Models/user';
import { AuthenticationService } from '../shared/Services/authentication.service';
import { Observable } from 'rxjs'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html' ,
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private router : Router, private appservice : AppServiceService, private loginservice: AuthenticationService ) { }

  // email : String;
  // public Password : String ;
   public user : any;
  // public hide : boolean = true;
 username = '';
 password = '';
  invalidLogin = false;
  role : any;



  ngOnInit() {
  
  }

signIn() {
  this.appservice.getUsers().subscribe(Response => {
      this.user = Response;
      console.log(this.user);
      this.user.forEach((element : any) => {
      console.log(element.email)
        if(this.username == element.email && this.password == element.password) {
        this.loginservice.authenticate(this.username, this.password); 
            // let userName = sessionStorage.getItem('username');
            // if(userName == element.email) {
            //   this.role = element.role;
            //   if(this.role == 'Admin' || this.role == 'Pmo' || this.role == 'Poc'){
            //     this.router.navigate(['dashboard']);
            //   }  else {
            //     this.router.navigate(['Participants']);
            //   }
            // }
          this.invalidLogin = false;
            // return false;
          }else {
            // console.log(error);
            this.invalidLogin = true;
            // return true;
          }
   
        })
      })
  }
  
  // })
  // this.loginservice.authenticate(this.username, this.password);
  //   this.router.navigate(['dashboard'])
  //   this.invalidLogin = false
//   } else
//     this.invalidLogin = true
  // }

  
}

